/* list all US cities */
SELECT *
FROM city_list
WHERE country = 'United States';