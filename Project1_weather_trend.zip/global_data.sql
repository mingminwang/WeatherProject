/*Extract data of global average temperature*/
SELECT *
FROM global_data;