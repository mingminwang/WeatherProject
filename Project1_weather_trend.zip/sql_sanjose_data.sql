/*Extract data for San Jose*/
SELECT city, year, avg_temp
FROM city_data
WHERE city = 'San Jose';